---
title:  "github.io 개편"
excerpt: "github.io 블로그 시작합니다 :)"

categories:
  - Blog
tags:
  - Blog
last_modified_at: 2021-04-09T11:41:00-09:00
---

본래 있었던 github.io를 없애고, 블로그 형태로 다시 시작하고자 합니다.

기존에 있던 Tistory 블로그는 공부한 내용을 중점으로 정리하는 방향으로 계속 사용하고자 하며,
해당 github.io 블로그를 통해 연구하거나, 진행했던 프로젝트, 참가한 CTF 라이트업을 작성하고자 합니다. 

앞으로 잘 부탁드려요 :) 