---
title: "Research"
permalink: /categories/Research/
layout: category
author_profile: true
taxonomy: Research
---

최근에 했던 연구들에 대한 글들을 모아두었습니다.